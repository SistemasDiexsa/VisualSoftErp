﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using VisualSoftErp.Clases;

namespace VisualSoftErp.Operacion.Compras.Formas
{
    public partial class Validarcompras : DevExpress.XtraBars.Ribbon.RibbonForm
    {
        decimal pIvaProv;
        string serieRM;
        int folioRM;

        public Validarcompras()
        {
            InitializeComponent();

            gridView1.OptionsSelection.MultiSelectMode = DevExpress.XtraGrid.Views.Grid.GridMultiSelectMode.CheckBoxRowSelect;
            gridView1.OptionsSelection.MultiSelect = true;

            cargaCombos();

            DevExpress.XtraSplashScreen.SplashScreenManager.CloseDefaultWaitForm();
        }

        private void cargaCombos()
        {
            combosCL cl = new combosCL();
            cl.strTabla = "Proveedores";
            cboProveedores.Properties.ValueMember = "Clave";
            cboProveedores.Properties.DisplayMember = "Des";
            cboProveedores.Properties.DataSource = cl.CargaCombos();
            cboProveedores.Properties.ForceInitialize();
            cboProveedores.Properties.PopupFilterMode = DevExpress.XtraEditors.PopupFilterMode.Contains;
            cboProveedores.Properties.PopulateColumns();
            cboProveedores.Properties.Columns["Clave"].Visible = false;
            cboProveedores.Properties.Columns["Piva"].Visible = false;
            cboProveedores.Properties.Columns["Plazo"].Visible = false;
            cboProveedores.Properties.Columns["Tiempodeentrega"].Visible = false;
            cboProveedores.Properties.Columns["Diastraslado"].Visible = false;
            cboProveedores.Properties.Columns["Lab"].Visible = false;
            cboProveedores.Properties.Columns["Via"].Visible = false;
            cboProveedores.Properties.Columns["BancosID"].Visible = false;
            cboProveedores.Properties.Columns["Cuentabancaria"].Visible = false;
            cboProveedores.Properties.Columns["C_Formapago"].Visible = false;
            cboProveedores.Properties.Columns["Retisr"].Visible = false;
            cboProveedores.Properties.Columns["Retiva"].Visible = false;
            cboProveedores.Properties.Columns["MonedasID"].Visible = false;
            cboProveedores.Properties.Columns["Contacto"].Visible = false;
            cboProveedores.Properties.Columns["Diasdesurtido"].Visible = false;
            cboProveedores.Properties.Columns["Diasdetraslado"].Visible = false;
            cboProveedores.ItemIndex = 0;


            cl.strTabla = "Monedas";
            cboMoneda.Properties.ValueMember = "Clave";
            cboMoneda.Properties.DisplayMember = "Des";
            cboMoneda.Properties.DataSource = cl.CargaCombos();
            cboMoneda.Properties.ForceInitialize();
            cboMoneda.Properties.PopupFilterMode = DevExpress.XtraEditors.PopupFilterMode.Contains;
            cboMoneda.Properties.PopulateColumns();
            cboMoneda.Properties.Columns["Clave"].Visible = false;
        }
       

        private void bbiCerrar_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            this.Close();
        }

        

        private void cargaRM()
        {
            try
            {
                ComprasCL cl = new ComprasCL();
                cl.intProveedoresID = Convert.ToInt32(cboProveedores.EditValue);
                gridControl1.DataSource = cl.CargaRM();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

 
        private void bbiCargarRM_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            cargaRM();
        }

        private void bbiGuardar_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            string result = Validar();

            if (result == "OK")
                Guardar();
              
        }

        private void Guardar()
        {
            try
            {
                System.Data.DataTable dtRM = new System.Data.DataTable("RM");
                dtRM.Columns.Add("Serie", Type.GetType("System.String"));
                dtRM.Columns.Add("Folio", Type.GetType("System.Int32"));

                string serie = string.Empty;
                int folio = 0;

                foreach (int i in gridView1.GetSelectedRows())
                {
                    serie = gridView1.GetRowCellValue(i, "Folio").ToString();
                    if (serie.Length > 0)
                    {
                        serie = gridView1.GetRowCellValue(i, "Serie").ToString();
                        folio = Convert.ToInt32(gridView1.GetRowCellValue(i, "Folio"));

                        dtRM.Rows.Add(serie, folio);
                    }
                }

                ComprasCL cl = new ComprasCL();
                cl.dtm = dtRM;
                cl.intProveedoresID = Convert.ToInt32(cboProveedores.EditValue);
                cl.strFactura = txtFac.Text;
                cl.fFecha = Convert.ToDateTime(dFechaFac.Text);
                cl.strMonedasID = cboMoneda.EditValue.ToString();
                cl.dTC = Convert.ToDecimal(txtTC.Text);
                cl.intPlazo = Convert.ToInt32(txtPlazo.Text);
                cl.decNeto = Convert.ToDecimal(txtNeto.Text);
                cl.intUsuarioID = globalCL.gv_UsuarioID;

                string result = cl.ComprasValidar();
                MessageBox.Show(result);

                if (result == "OK")
                {
                    limpiacajas();
                }

            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void limpiacajas()
        {
            gridControl1.DataSource = null;
            txtFac.Text = string.Empty;
            txtTC.Text = string.Empty;
            txtNeto.Text = string.Empty;
            txtPlazo.Text = string.Empty;
        }

        private string Validar()
        {
            globalCL clg = new globalCL();

            if (cboProveedores.ItemIndex == -1)
            {
                return "Seleccione un proveedor";
            }
            if (txtFac.Text.Length == 0)
            {
                return "Teclee la factura";
            }
            if (!clg.esFecha(dFechaFac.Text))
            {
                return "Teclee la fecha de la factura";
            }
            string result = clg.GM_CierredemodulosStatus(Convert.ToDateTime(dFechaFac.Text).Year, Convert.ToDateTime(dFechaFac.Text).Month, "COM");
            if (result == "C")
            {
                return "Este mes está cerrado, no se puede actualizar";
            }

            if (cboMoneda.ItemIndex == -1)
            {
                return "Seleccione una moneda";
            }

            if (cboMoneda.EditValue.ToString() == "MXN")
                txtTC.Text = "1";
            else
            {
                if (!clg.esNumerico(txtTC.Text))
                {
                    return "Teclee el tipo de cambio";
                }
            }

            if (!clg.esNumerico(txtPlazo.Text))
            {
                return "Teclee el plazo";
            }

            if (!clg.esNumerico(txtNeto.Text))
            {
                return "Teclee el neto de la factura";
            }

            decimal dNeto = 0;
            decimal tNeto = 0;
            string dato = string.Empty;

            foreach (int i in gridView1.GetSelectedRows())
            {
                dato = gridView1.GetRowCellValue(i, "Folio").ToString();
                if (dato.Length > 0)
                {
                    dNeto = Convert.ToDecimal(gridView1.GetRowCellValue(i, "Neto"));
                    tNeto += dNeto;
                }
            }

            if (tNeto != Convert.ToDecimal(txtNeto.Text))
            {
                return "No concuerda el neto de la factura vs el de la recepción de mercancía";
            }


                    return "OK";
        }

        private void bbiNuevo_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            limpiacajas();
        }

        private void cboProveedores_EditValueChanged_1(object sender, EventArgs e)
        {
            object orow = cboProveedores.Properties.GetDataSourceRowByKeyValue(cboProveedores.EditValue);
            if (orow != null)
            {
                txtPlazo.Text = ((DataRowView)orow)["Plazo"].ToString();
                pIvaProv = Convert.ToDecimal(((DataRowView)orow)["Piva"]);
                cboMoneda.EditValue = ((DataRowView)orow)["MonedasID"].ToString();
            }
        }

        private void gridView1_RowClick(object sender, DevExpress.XtraGrid.Views.Grid.RowClickEventArgs e)
        {
            serieRM = gridView1.GetRowCellValue(gridView1.FocusedRowHandle, "Serie").ToString();
            folioRM = Convert.ToInt32(gridView1.GetRowCellValue(gridView1.FocusedRowHandle, "Folio"));

            LlenaOC();
        }

        private void LlenaOC()
        {            
            try
            {
                RecepciondemercanciaCL cl = new RecepciondemercanciaCL();
                cl.strSerie = serieRM;
                cl.intFolio = folioRM;
                gridControl2.DataSource = cl.RecepciondemercanciaOCGrid();

            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void bbiCambiarFecha_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            try
            {
                if (folioRM == 0)
                {
                    MessageBox.Show("Seleccione una recepción de mercancía");
                    return;
                }

                DialogResult Result = MessageBox.Show("Desea modificar la fecha a la RM: " + serieRM + folioRM.ToString(), "Modificar", MessageBoxButtons.YesNo);
                if (Result.ToString() != "Yes")
                {
                    return;
                }

                RecepciondemercanciaCL cl = new RecepciondemercanciaCL();
                cl.strSerie = serieRM;
                cl.intFolio = folioRM;
                cl.fFecha = Convert.ToDateTime(dFechaFac.Text);
                string result = cl.RecepciondemercanciasCambiaFecha();
                MessageBox.Show(result);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}