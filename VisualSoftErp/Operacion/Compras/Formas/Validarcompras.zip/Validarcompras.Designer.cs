﻿namespace VisualSoftErp.Operacion.Compras.Formas
{
    partial class Validarcompras
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Validarcompras));
            this.tabbedView = new DevExpress.XtraBars.Docking2010.Views.Tabbed.TabbedView(this.components);
            this.ribbonControl = new DevExpress.XtraBars.Ribbon.RibbonControl();
            this.skinRibbonGalleryBarItem = new DevExpress.XtraBars.SkinRibbonGalleryBarItem();
            this.barSubItemNavigation = new DevExpress.XtraBars.BarSubItem();
            this.employeesBarButtonItem = new DevExpress.XtraBars.BarButtonItem();
            this.customersBarButtonItem = new DevExpress.XtraBars.BarButtonItem();
            this.skinDropDownButtonItem = new DevExpress.XtraBars.SkinDropDownButtonItem();
            this.skinPaletteRibbonGalleryBarItem = new DevExpress.XtraBars.SkinPaletteRibbonGalleryBarItem();
            this.bbiNuevo = new DevExpress.XtraBars.BarButtonItem();
            this.bbiGuardar = new DevExpress.XtraBars.BarButtonItem();
            this.bbiCargaRM = new DevExpress.XtraBars.BarButtonItem();
            this.bbiCerrar = new DevExpress.XtraBars.BarButtonItem();
            this.bbiCargarRM = new DevExpress.XtraBars.BarButtonItem();
            this.ribbonPage = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.ribbonPageGroup1 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonStatusBar = new DevExpress.XtraBars.Ribbon.RibbonStatusBar();
            this.splitContainerControl1 = new DevExpress.XtraEditors.SplitContainerControl();
            this.splitContainerControl2 = new DevExpress.XtraEditors.SplitContainerControl();
            this.labelControl8 = new DevExpress.XtraEditors.LabelControl();
            this.txtPlazo = new DevExpress.XtraEditors.TextEdit();
            this.cboMoneda = new DevExpress.XtraEditors.LookUpEdit();
            this.dFechaFac = new DevExpress.XtraEditors.DateEdit();
            this.txtNeto = new DevExpress.XtraEditors.TextEdit();
            this.txtTC = new DevExpress.XtraEditors.TextEdit();
            this.txtFac = new DevExpress.XtraEditors.TextEdit();
            this.cboProveedores = new DevExpress.XtraEditors.LookUpEdit();
            this.labelControl7 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl6 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl5 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl4 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl3 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl2 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
            this.gridControl1 = new DevExpress.XtraGrid.GridControl();
            this.gridView1 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumnSerie = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumnFolio = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumnFecha = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumnST = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumnIva = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumnNeto = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridControl2 = new DevExpress.XtraGrid.GridControl();
            this.gridView2 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.bbiCambiarFecha = new DevExpress.XtraBars.BarButtonItem();
            ((System.ComponentModel.ISupportInitialize)(this.tabbedView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ribbonControl)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl1.Panel1)).BeginInit();
            this.splitContainerControl1.Panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl1.Panel2)).BeginInit();
            this.splitContainerControl1.Panel2.SuspendLayout();
            this.splitContainerControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl2.Panel1)).BeginInit();
            this.splitContainerControl2.Panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl2.Panel2)).BeginInit();
            this.splitContainerControl2.Panel2.SuspendLayout();
            this.splitContainerControl2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtPlazo.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboMoneda.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dFechaFac.Properties.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dFechaFac.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtNeto.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTC.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtFac.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboProveedores.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridControl1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridControl2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView2)).BeginInit();
            this.SuspendLayout();
            // 
            // ribbonControl
            // 
            this.ribbonControl.ExpandCollapseItem.Id = 0;
            this.ribbonControl.Items.AddRange(new DevExpress.XtraBars.BarItem[] {
            this.ribbonControl.ExpandCollapseItem,
            this.ribbonControl.SearchEditItem,
            this.skinRibbonGalleryBarItem,
            this.barSubItemNavigation,
            this.employeesBarButtonItem,
            this.customersBarButtonItem,
            this.skinDropDownButtonItem,
            this.skinPaletteRibbonGalleryBarItem,
            this.bbiNuevo,
            this.bbiGuardar,
            this.bbiCargaRM,
            this.bbiCerrar,
            this.bbiCargarRM,
            this.bbiCambiarFecha});
            this.ribbonControl.Location = new System.Drawing.Point(0, 0);
            this.ribbonControl.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.ribbonControl.MaxItemId = 54;
            this.ribbonControl.MdiMergeStyle = DevExpress.XtraBars.Ribbon.RibbonMdiMergeStyle.Always;
            this.ribbonControl.Name = "ribbonControl";
            this.ribbonControl.OptionsMenuMinWidth = 385;
            this.ribbonControl.Pages.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPage[] {
            this.ribbonPage});
            this.ribbonControl.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonControlStyle.Office2013;
            this.ribbonControl.ShowApplicationButton = DevExpress.Utils.DefaultBoolean.False;
            this.ribbonControl.Size = new System.Drawing.Size(1823, 181);
            this.ribbonControl.StatusBar = this.ribbonStatusBar;
            this.ribbonControl.ToolbarLocation = DevExpress.XtraBars.Ribbon.RibbonQuickAccessToolbarLocation.Hidden;
            // 
            // skinRibbonGalleryBarItem
            // 
            this.skinRibbonGalleryBarItem.Id = 14;
            this.skinRibbonGalleryBarItem.Name = "skinRibbonGalleryBarItem";
            // 
            // barSubItemNavigation
            // 
            this.barSubItemNavigation.Caption = "Navigation";
            this.barSubItemNavigation.Id = 15;
            this.barSubItemNavigation.ImageOptions.ImageUri.Uri = "NavigationBar";
            this.barSubItemNavigation.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.employeesBarButtonItem),
            new DevExpress.XtraBars.LinkPersistInfo(this.customersBarButtonItem)});
            this.barSubItemNavigation.Name = "barSubItemNavigation";
            // 
            // employeesBarButtonItem
            // 
            this.employeesBarButtonItem.Id = 50;
            this.employeesBarButtonItem.Name = "employeesBarButtonItem";
            // 
            // customersBarButtonItem
            // 
            this.customersBarButtonItem.Id = 51;
            this.customersBarButtonItem.Name = "customersBarButtonItem";
            // 
            // skinDropDownButtonItem
            // 
            this.skinDropDownButtonItem.Id = 46;
            this.skinDropDownButtonItem.Name = "skinDropDownButtonItem";
            // 
            // skinPaletteRibbonGalleryBarItem
            // 
            this.skinPaletteRibbonGalleryBarItem.Caption = "$newskinpalettename$";
            this.skinPaletteRibbonGalleryBarItem.Id = 47;
            this.skinPaletteRibbonGalleryBarItem.Name = "skinPaletteRibbonGalleryBarItem";
            // 
            // bbiNuevo
            // 
            this.bbiNuevo.Caption = "Nuevo";
            this.bbiNuevo.Id = 46;
            this.bbiNuevo.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("bbiNuevo.ImageOptions.SvgImage")));
            this.bbiNuevo.Name = "bbiNuevo";
            this.bbiNuevo.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.bbiNuevo_ItemClick);
            // 
            // bbiGuardar
            // 
            this.bbiGuardar.Caption = "Guardar";
            this.bbiGuardar.Id = 47;
            this.bbiGuardar.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("bbiGuardar.ImageOptions.Image")));
            this.bbiGuardar.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("bbiGuardar.ImageOptions.LargeImage")));
            this.bbiGuardar.Name = "bbiGuardar";
            this.bbiGuardar.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.bbiGuardar_ItemClick);
            // 
            // bbiCargaRM
            // 
            this.bbiCargaRM.Caption = "Cargar RM";
            this.bbiCargaRM.Id = 48;
            this.bbiCargaRM.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("bbiCargaRM.ImageOptions.SvgImage")));
            this.bbiCargaRM.Name = "bbiCargaRM";
            // 
            // bbiCerrar
            // 
            this.bbiCerrar.Caption = "Cerrar";
            this.bbiCerrar.Id = 49;
            this.bbiCerrar.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("bbiCerrar.ImageOptions.Image")));
            this.bbiCerrar.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("bbiCerrar.ImageOptions.LargeImage")));
            this.bbiCerrar.Name = "bbiCerrar";
            this.bbiCerrar.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.bbiCerrar_ItemClick);
            // 
            // bbiCargarRM
            // 
            this.bbiCargarRM.Caption = "Cargar RM";
            this.bbiCargarRM.Id = 52;
            this.bbiCargarRM.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("bbiCargarRM.ImageOptions.SvgImage")));
            this.bbiCargarRM.Name = "bbiCargarRM";
            this.bbiCargarRM.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.bbiCargarRM_ItemClick);
            // 
            // ribbonPage
            // 
            this.ribbonPage.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.ribbonPageGroup1});
            this.ribbonPage.Name = "ribbonPage";
            this.ribbonPage.Text = "Home";
            // 
            // ribbonPageGroup1
            // 
            this.ribbonPageGroup1.ItemLinks.Add(this.bbiNuevo);
            this.ribbonPageGroup1.ItemLinks.Add(this.bbiGuardar);
            this.ribbonPageGroup1.ItemLinks.Add(this.bbiCargarRM);
            this.ribbonPageGroup1.ItemLinks.Add(this.bbiCambiarFecha);
            this.ribbonPageGroup1.ItemLinks.Add(this.bbiCerrar);
            this.ribbonPageGroup1.Name = "ribbonPageGroup1";
            this.ribbonPageGroup1.Text = "Acciones";
            // 
            // ribbonStatusBar
            // 
            this.ribbonStatusBar.Location = new System.Drawing.Point(0, 986);
            this.ribbonStatusBar.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.ribbonStatusBar.Name = "ribbonStatusBar";
            this.ribbonStatusBar.Ribbon = this.ribbonControl;
            this.ribbonStatusBar.Size = new System.Drawing.Size(1823, 29);
            // 
            // splitContainerControl1
            // 
            this.splitContainerControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainerControl1.Horizontal = false;
            this.splitContainerControl1.Location = new System.Drawing.Point(0, 181);
            this.splitContainerControl1.Name = "splitContainerControl1";
            // 
            // splitContainerControl1.Panel1
            // 
            this.splitContainerControl1.Panel1.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Default;
            this.splitContainerControl1.Panel1.Controls.Add(this.splitContainerControl2);
            this.splitContainerControl1.Panel1.Text = "Panel1";
            // 
            // splitContainerControl1.Panel2
            // 
            this.splitContainerControl1.Panel2.Controls.Add(this.gridControl2);
            this.splitContainerControl1.Panel2.Text = "Panel2";
            this.splitContainerControl1.Size = new System.Drawing.Size(1823, 805);
            this.splitContainerControl1.SplitterPosition = 394;
            this.splitContainerControl1.TabIndex = 4;
            // 
            // splitContainerControl2
            // 
            this.splitContainerControl2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainerControl2.Location = new System.Drawing.Point(0, 0);
            this.splitContainerControl2.Name = "splitContainerControl2";
            // 
            // splitContainerControl2.Panel1
            // 
            this.splitContainerControl2.Panel1.Controls.Add(this.labelControl8);
            this.splitContainerControl2.Panel1.Controls.Add(this.txtPlazo);
            this.splitContainerControl2.Panel1.Controls.Add(this.cboMoneda);
            this.splitContainerControl2.Panel1.Controls.Add(this.dFechaFac);
            this.splitContainerControl2.Panel1.Controls.Add(this.txtNeto);
            this.splitContainerControl2.Panel1.Controls.Add(this.txtTC);
            this.splitContainerControl2.Panel1.Controls.Add(this.txtFac);
            this.splitContainerControl2.Panel1.Controls.Add(this.cboProveedores);
            this.splitContainerControl2.Panel1.Controls.Add(this.labelControl7);
            this.splitContainerControl2.Panel1.Controls.Add(this.labelControl6);
            this.splitContainerControl2.Panel1.Controls.Add(this.labelControl5);
            this.splitContainerControl2.Panel1.Controls.Add(this.labelControl4);
            this.splitContainerControl2.Panel1.Controls.Add(this.labelControl3);
            this.splitContainerControl2.Panel1.Controls.Add(this.labelControl2);
            this.splitContainerControl2.Panel1.Controls.Add(this.labelControl1);
            this.splitContainerControl2.Panel1.Text = "Panel1";
            // 
            // splitContainerControl2.Panel2
            // 
            this.splitContainerControl2.Panel2.Controls.Add(this.gridControl1);
            this.splitContainerControl2.Panel2.Text = "Panel2";
            this.splitContainerControl2.Size = new System.Drawing.Size(1819, 390);
            this.splitContainerControl2.SplitterPosition = 890;
            this.splitContainerControl2.TabIndex = 15;
            // 
            // labelControl8
            // 
            this.labelControl8.Location = new System.Drawing.Point(371, 87);
            this.labelControl8.Name = "labelControl8";
            this.labelControl8.Size = new System.Drawing.Size(196, 16);
            this.labelControl8.TabIndex = 29;
            this.labelControl8.Text = "(capture serie y folio sin espacios)";
            // 
            // txtPlazo
            // 
            this.txtPlazo.Location = new System.Drawing.Point(163, 241);
            this.txtPlazo.MenuManager = this.ribbonControl;
            this.txtPlazo.Name = "txtPlazo";
            this.txtPlazo.Size = new System.Drawing.Size(186, 22);
            this.txtPlazo.TabIndex = 28;
            // 
            // cboMoneda
            // 
            this.cboMoneda.Location = new System.Drawing.Point(163, 164);
            this.cboMoneda.MenuManager = this.ribbonControl;
            this.cboMoneda.Name = "cboMoneda";
            this.cboMoneda.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.cboMoneda.Size = new System.Drawing.Size(186, 22);
            this.cboMoneda.TabIndex = 27;
            // 
            // dFechaFac
            // 
            this.dFechaFac.EditValue = null;
            this.dFechaFac.Location = new System.Drawing.Point(163, 123);
            this.dFechaFac.MenuManager = this.ribbonControl;
            this.dFechaFac.Name = "dFechaFac";
            this.dFechaFac.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.dFechaFac.Properties.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.dFechaFac.Size = new System.Drawing.Size(186, 22);
            this.dFechaFac.TabIndex = 26;
            // 
            // txtNeto
            // 
            this.txtNeto.Location = new System.Drawing.Point(163, 279);
            this.txtNeto.MenuManager = this.ribbonControl;
            this.txtNeto.Name = "txtNeto";
            this.txtNeto.Size = new System.Drawing.Size(186, 22);
            this.txtNeto.TabIndex = 25;
            // 
            // txtTC
            // 
            this.txtTC.Location = new System.Drawing.Point(163, 205);
            this.txtTC.MenuManager = this.ribbonControl;
            this.txtTC.Name = "txtTC";
            this.txtTC.Size = new System.Drawing.Size(186, 22);
            this.txtTC.TabIndex = 24;
            // 
            // txtFac
            // 
            this.txtFac.Location = new System.Drawing.Point(163, 81);
            this.txtFac.MenuManager = this.ribbonControl;
            this.txtFac.Name = "txtFac";
            this.txtFac.Size = new System.Drawing.Size(186, 22);
            this.txtFac.TabIndex = 23;
            // 
            // cboProveedores
            // 
            this.cboProveedores.Location = new System.Drawing.Point(163, 42);
            this.cboProveedores.MenuManager = this.ribbonControl;
            this.cboProveedores.Name = "cboProveedores";
            this.cboProveedores.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.cboProveedores.Size = new System.Drawing.Size(703, 22);
            this.cboProveedores.TabIndex = 22;
            this.cboProveedores.EditValueChanged += new System.EventHandler(this.cboProveedores_EditValueChanged_1);
            // 
            // labelControl7
            // 
            this.labelControl7.Location = new System.Drawing.Point(36, 282);
            this.labelControl7.Name = "labelControl7";
            this.labelControl7.Size = new System.Drawing.Size(26, 16);
            this.labelControl7.TabIndex = 21;
            this.labelControl7.Text = "Neto";
            // 
            // labelControl6
            // 
            this.labelControl6.Location = new System.Drawing.Point(36, 244);
            this.labelControl6.Name = "labelControl6";
            this.labelControl6.Size = new System.Drawing.Size(30, 16);
            this.labelControl6.TabIndex = 20;
            this.labelControl6.Text = "Plazo";
            // 
            // labelControl5
            // 
            this.labelControl5.Location = new System.Drawing.Point(36, 208);
            this.labelControl5.Name = "labelControl5";
            this.labelControl5.Size = new System.Drawing.Size(88, 16);
            this.labelControl5.TabIndex = 19;
            this.labelControl5.Text = "Tipo de cambio";
            // 
            // labelControl4
            // 
            this.labelControl4.Location = new System.Drawing.Point(36, 170);
            this.labelControl4.Name = "labelControl4";
            this.labelControl4.Size = new System.Drawing.Size(45, 16);
            this.labelControl4.TabIndex = 18;
            this.labelControl4.Text = "Moneda";
            // 
            // labelControl3
            // 
            this.labelControl3.Location = new System.Drawing.Point(36, 129);
            this.labelControl3.Name = "labelControl3";
            this.labelControl3.Size = new System.Drawing.Size(78, 16);
            this.labelControl3.TabIndex = 17;
            this.labelControl3.Text = "Fecha factura";
            // 
            // labelControl2
            // 
            this.labelControl2.Location = new System.Drawing.Point(36, 87);
            this.labelControl2.Name = "labelControl2";
            this.labelControl2.Size = new System.Drawing.Size(43, 16);
            this.labelControl2.TabIndex = 16;
            this.labelControl2.Text = "Factura";
            // 
            // labelControl1
            // 
            this.labelControl1.Location = new System.Drawing.Point(36, 45);
            this.labelControl1.Name = "labelControl1";
            this.labelControl1.Size = new System.Drawing.Size(58, 16);
            this.labelControl1.TabIndex = 15;
            this.labelControl1.Text = "Proveedor";
            // 
            // gridControl1
            // 
            this.gridControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gridControl1.Location = new System.Drawing.Point(0, 0);
            this.gridControl1.MainView = this.gridView1;
            this.gridControl1.MenuManager = this.ribbonControl;
            this.gridControl1.Name = "gridControl1";
            this.gridControl1.Size = new System.Drawing.Size(914, 390);
            this.gridControl1.TabIndex = 1;
            this.gridControl1.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridView1});
            // 
            // gridView1
            // 
            this.gridView1.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumnSerie,
            this.gridColumnFolio,
            this.gridColumnFecha,
            this.gridColumnST,
            this.gridColumnIva,
            this.gridColumnNeto});
            this.gridView1.GridControl = this.gridControl1;
            this.gridView1.Name = "gridView1";
            this.gridView1.OptionsView.ShowGroupPanel = false;
            this.gridView1.OptionsView.ShowViewCaption = true;
            this.gridView1.ViewCaption = "RECEPCIONES DE MERCANCIA";
            this.gridView1.RowClick += new DevExpress.XtraGrid.Views.Grid.RowClickEventHandler(this.gridView1_RowClick);
            // 
            // gridColumnSerie
            // 
            this.gridColumnSerie.Caption = "Serie";
            this.gridColumnSerie.FieldName = "Serie";
            this.gridColumnSerie.MinWidth = 25;
            this.gridColumnSerie.Name = "gridColumnSerie";
            this.gridColumnSerie.Visible = true;
            this.gridColumnSerie.VisibleIndex = 0;
            this.gridColumnSerie.Width = 94;
            // 
            // gridColumnFolio
            // 
            this.gridColumnFolio.Caption = "Folio";
            this.gridColumnFolio.FieldName = "Folio";
            this.gridColumnFolio.MinWidth = 25;
            this.gridColumnFolio.Name = "gridColumnFolio";
            this.gridColumnFolio.Visible = true;
            this.gridColumnFolio.VisibleIndex = 1;
            this.gridColumnFolio.Width = 94;
            // 
            // gridColumnFecha
            // 
            this.gridColumnFecha.Caption = "Fecha";
            this.gridColumnFecha.FieldName = "Fecha";
            this.gridColumnFecha.MinWidth = 25;
            this.gridColumnFecha.Name = "gridColumnFecha";
            this.gridColumnFecha.Visible = true;
            this.gridColumnFecha.VisibleIndex = 2;
            this.gridColumnFecha.Width = 94;
            // 
            // gridColumnST
            // 
            this.gridColumnST.Caption = "Subtotal";
            this.gridColumnST.DisplayFormat.FormatString = "c2";
            this.gridColumnST.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumnST.FieldName = "Subtotal";
            this.gridColumnST.MinWidth = 25;
            this.gridColumnST.Name = "gridColumnST";
            this.gridColumnST.Visible = true;
            this.gridColumnST.VisibleIndex = 3;
            this.gridColumnST.Width = 94;
            // 
            // gridColumnIva
            // 
            this.gridColumnIva.Caption = "Iva";
            this.gridColumnIva.DisplayFormat.FormatString = "c2";
            this.gridColumnIva.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumnIva.FieldName = "Iva";
            this.gridColumnIva.MinWidth = 25;
            this.gridColumnIva.Name = "gridColumnIva";
            this.gridColumnIva.Visible = true;
            this.gridColumnIva.VisibleIndex = 4;
            this.gridColumnIva.Width = 94;
            // 
            // gridColumnNeto
            // 
            this.gridColumnNeto.Caption = "Neto";
            this.gridColumnNeto.DisplayFormat.FormatString = "c2";
            this.gridColumnNeto.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumnNeto.FieldName = "Neto";
            this.gridColumnNeto.MinWidth = 25;
            this.gridColumnNeto.Name = "gridColumnNeto";
            this.gridColumnNeto.Visible = true;
            this.gridColumnNeto.VisibleIndex = 5;
            this.gridColumnNeto.Width = 94;
            // 
            // gridControl2
            // 
            this.gridControl2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gridControl2.Location = new System.Drawing.Point(0, 0);
            this.gridControl2.MainView = this.gridView2;
            this.gridControl2.MenuManager = this.ribbonControl;
            this.gridControl2.Name = "gridControl2";
            this.gridControl2.Size = new System.Drawing.Size(1823, 396);
            this.gridControl2.TabIndex = 0;
            this.gridControl2.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridView2});
            // 
            // gridView2
            // 
            this.gridView2.GridControl = this.gridControl2;
            this.gridView2.Name = "gridView2";
            this.gridView2.OptionsView.ShowGroupPanel = false;
            // 
            // bbiCambiarFecha
            // 
            this.bbiCambiarFecha.Caption = "Cambiar fecha";
            this.bbiCambiarFecha.Id = 53;
            this.bbiCambiarFecha.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("bbiCambiarFecha.ImageOptions.SvgImage")));
            this.bbiCambiarFecha.Name = "bbiCambiarFecha";
            this.bbiCambiarFecha.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.bbiCambiarFecha_ItemClick);
            // 
            // Validarcompras
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1823, 1015);
            this.Controls.Add(this.splitContainerControl1);
            this.Controls.Add(this.ribbonStatusBar);
            this.Controls.Add(this.ribbonControl);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "Validarcompras";
            this.Ribbon = this.ribbonControl;
            this.StatusBar = this.ribbonStatusBar;
            this.Text = "Validar compras";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            ((System.ComponentModel.ISupportInitialize)(this.tabbedView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ribbonControl)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl1.Panel1)).EndInit();
            this.splitContainerControl1.Panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl1.Panel2)).EndInit();
            this.splitContainerControl1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl1)).EndInit();
            this.splitContainerControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl2.Panel1)).EndInit();
            this.splitContainerControl2.Panel1.ResumeLayout(false);
            this.splitContainerControl2.Panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl2.Panel2)).EndInit();
            this.splitContainerControl2.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl2)).EndInit();
            this.splitContainerControl2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.txtPlazo.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboMoneda.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dFechaFac.Properties.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dFechaFac.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtNeto.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTC.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtFac.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboProveedores.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridControl1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridControl2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private DevExpress.XtraBars.Docking2010.Views.Tabbed.TabbedView tabbedView;
        private DevExpress.XtraBars.Ribbon.RibbonControl ribbonControl;
        private DevExpress.XtraBars.Ribbon.RibbonPage ribbonPage;
        private DevExpress.XtraBars.Ribbon.RibbonStatusBar ribbonStatusBar;
        private DevExpress.XtraBars.BarSubItem barSubItemNavigation;
        private DevExpress.XtraBars.SkinRibbonGalleryBarItem skinRibbonGalleryBarItem;
        private DevExpress.XtraBars.BarButtonItem employeesBarButtonItem;
        private DevExpress.XtraBars.BarButtonItem customersBarButtonItem;
        private DevExpress.XtraBars.SkinDropDownButtonItem skinDropDownButtonItem;
        private DevExpress.XtraBars.SkinPaletteRibbonGalleryBarItem skinPaletteRibbonGalleryBarItem;
        private DevExpress.XtraEditors.SplitContainerControl splitContainerControl1;
        private DevExpress.XtraBars.BarButtonItem bbiNuevo;
        private DevExpress.XtraBars.BarButtonItem bbiGuardar;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup1;
        private DevExpress.XtraBars.BarButtonItem bbiCargaRM;
        private DevExpress.XtraBars.BarButtonItem bbiCerrar;
        private DevExpress.XtraBars.BarButtonItem bbiCargarRM;
        private DevExpress.XtraEditors.SplitContainerControl splitContainerControl2;
        private DevExpress.XtraEditors.LabelControl labelControl8;
        private DevExpress.XtraEditors.TextEdit txtPlazo;
        private DevExpress.XtraEditors.LookUpEdit cboMoneda;
        private DevExpress.XtraEditors.DateEdit dFechaFac;
        private DevExpress.XtraEditors.TextEdit txtNeto;
        private DevExpress.XtraEditors.TextEdit txtTC;
        private DevExpress.XtraEditors.TextEdit txtFac;
        private DevExpress.XtraEditors.LookUpEdit cboProveedores;
        private DevExpress.XtraEditors.LabelControl labelControl7;
        private DevExpress.XtraEditors.LabelControl labelControl6;
        private DevExpress.XtraEditors.LabelControl labelControl5;
        private DevExpress.XtraEditors.LabelControl labelControl4;
        private DevExpress.XtraEditors.LabelControl labelControl3;
        private DevExpress.XtraEditors.LabelControl labelControl2;
        private DevExpress.XtraEditors.LabelControl labelControl1;
        private DevExpress.XtraGrid.GridControl gridControl1;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView1;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumnSerie;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumnFolio;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumnFecha;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumnST;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumnIva;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumnNeto;
        private DevExpress.XtraGrid.GridControl gridControl2;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView2;
        private DevExpress.XtraBars.BarButtonItem bbiCambiarFecha;
    }
}