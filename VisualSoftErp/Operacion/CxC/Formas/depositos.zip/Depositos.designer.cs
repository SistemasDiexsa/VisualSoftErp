﻿namespace VisualSoftErp.Catalogos
{
    partial class Depositos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Depositos));
            this.tabbedView = new DevExpress.XtraBars.Docking2010.Views.Tabbed.TabbedView(this.components);
            this.ribbonControl = new DevExpress.XtraBars.Ribbon.RibbonControl();
            this.skinRibbonGalleryBarItem = new DevExpress.XtraBars.SkinRibbonGalleryBarItem();
            this.barSubItemNavigation = new DevExpress.XtraBars.BarSubItem();
            this.employeesBarButtonItem = new DevExpress.XtraBars.BarButtonItem();
            this.customersBarButtonItem = new DevExpress.XtraBars.BarButtonItem();
            this.bbiNuevo = new DevExpress.XtraBars.BarButtonItem();
            this.bbiCancelar = new DevExpress.XtraBars.BarButtonItem();
            this.bbiGuardar = new DevExpress.XtraBars.BarButtonItem();
            this.bbiImprimir = new DevExpress.XtraBars.BarButtonItem();
            this.bbiCerrar = new DevExpress.XtraBars.BarButtonItem();
            this.bbiRegresar = new DevExpress.XtraBars.BarButtonItem();
            this.bbiCargarfacturas = new DevExpress.XtraBars.BarButtonItem();
            this.bbiTodos = new DevExpress.XtraBars.BarButtonItem();
            this.bbiRegistrados = new DevExpress.XtraBars.BarButtonItem();
            this.bbiCancelados = new DevExpress.XtraBars.BarButtonItem();
            this.bbiVerificar = new DevExpress.XtraBars.BarButtonItem();
            this.bbiEnviar = new DevExpress.XtraBars.BarButtonItem();
            this.ribbonPage = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.ribbonPageGroupNavigation = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPage1 = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.ribbonPageGroup1 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonStatusBar = new DevExpress.XtraBars.Ribbon.RibbonStatusBar();
            this.officeNavigationBar = new DevExpress.XtraBars.Navigation.OfficeNavigationBar();
            this.navBarControl = new DevExpress.XtraNavBar.NavBarControl();
            this.employeesNavBarGroup = new DevExpress.XtraNavBar.NavBarGroup();
            this.navBarItemEne = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItemFeb = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItemMar = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItemAbr = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItemMay = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItemJun = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItemJul = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItemAgo = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItemsep = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItemOct = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItemNov = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItemDic = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItemTodos = new DevExpress.XtraNavBar.NavBarItem();
            this.navigationFrame = new DevExpress.XtraBars.Navigation.NavigationFrame();
            this.employeesNavigationPage = new DevExpress.XtraBars.Navigation.NavigationPage();
            this.popUpCancelar = new DevExpress.XtraBars.PopupControlContainer(this.components);
            this.groupControl3 = new DevExpress.XtraEditors.GroupControl();
            this.simpleButton2 = new DevExpress.XtraEditors.SimpleButton();
            this.labelControl20 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl19 = new DevExpress.XtraEditors.LabelControl();
            this.btnAut = new DevExpress.XtraEditors.SimpleButton();
            this.txtPassword = new DevExpress.XtraEditors.TextEdit();
            this.txtLogin = new DevExpress.XtraEditors.TextEdit();
            this.labelControl18 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl17 = new DevExpress.XtraEditors.LabelControl();
            this.gridControlPrincipal = new DevExpress.XtraGrid.GridControl();
            this.gridViewPrincipal = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.customersNavigationPage = new DevExpress.XtraBars.Navigation.NavigationPage();
            this.splitContainerControl1 = new DevExpress.XtraEditors.SplitContainerControl();
            this.chkTimbrar = new DevExpress.XtraEditors.CheckEdit();
            this.labelControl12 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl11 = new DevExpress.XtraEditors.LabelControl();
            this.txtFolio = new DevExpress.XtraEditors.TextEdit();
            this.cboSerie = new DevExpress.XtraEditors.LookUpEdit();
            this.groupControl2 = new DevExpress.XtraEditors.GroupControl();
            this.dateEditFecha = new DevExpress.XtraEditors.DateEdit();
            this.cboC_Formapago = new DevExpress.XtraEditors.LookUpEdit();
            this.cboBancosId = new DevExpress.XtraEditors.LookUpEdit();
            this.labelControl10 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl9 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl8 = new DevExpress.XtraEditors.LabelControl();
            this.txtNumerooperacion = new DevExpress.XtraEditors.TextEdit();
            this.txtCuentaordenante = new DevExpress.XtraEditors.TextEdit();
            this.labelControl7 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl6 = new DevExpress.XtraEditors.LabelControl();
            this.txtHora = new DevExpress.XtraEditors.TextEdit();
            this.labelControl5 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl4 = new DevExpress.XtraEditors.LabelControl();
            this.cboClientesID = new DevExpress.XtraEditors.LookUpEdit();
            this.groupControl1 = new DevExpress.XtraEditors.GroupControl();
            this.txtTipodecambio = new DevExpress.XtraEditors.TextEdit();
            this.labelControl3 = new DevExpress.XtraEditors.LabelControl();
            this.txtImporte = new DevExpress.XtraEditors.TextEdit();
            this.labelControl2 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
            this.cboCuentasbancariaID = new DevExpress.XtraEditors.LookUpEdit();
            this.gridControlDetalle = new DevExpress.XtraGrid.GridControl();
            this.gridViewDetalle = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumnSeriecfdi = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumnFoliocfdi = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumnFechafac = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumnFechavence = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumnImporte = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumnSupago = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumnDiasvence = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumnMoneda = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumnCxCID = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumnTipoMov = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumnMP = new DevExpress.XtraGrid.Columns.GridColumn();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.bbiCargarCxC = new DevExpress.XtraBars.BarButtonItem();
            this.btnTomaImporte = new DevExpress.XtraEditors.SimpleButton();
            ((System.ComponentModel.ISupportInitialize)(this.tabbedView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ribbonControl)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.officeNavigationBar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.navBarControl)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.navigationFrame)).BeginInit();
            this.navigationFrame.SuspendLayout();
            this.employeesNavigationPage.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.popUpCancelar)).BeginInit();
            this.popUpCancelar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl3)).BeginInit();
            this.groupControl3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtPassword.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtLogin.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridControlPrincipal)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewPrincipal)).BeginInit();
            this.customersNavigationPage.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl1)).BeginInit();
            this.splitContainerControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chkTimbrar.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtFolio.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboSerie.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl2)).BeginInit();
            this.groupControl2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dateEditFecha.Properties.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateEditFecha.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboC_Formapago.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboBancosId.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtNumerooperacion.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCuentaordenante.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtHora.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboClientesID.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl1)).BeginInit();
            this.groupControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtTipodecambio.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtImporte.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboCuentasbancariaID.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridControlDetalle)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewDetalle)).BeginInit();
            this.SuspendLayout();
            // 
            // ribbonControl
            // 
            this.ribbonControl.ExpandCollapseItem.Id = 0;
            this.ribbonControl.Items.AddRange(new DevExpress.XtraBars.BarItem[] {
            this.ribbonControl.ExpandCollapseItem,
            this.ribbonControl.SearchEditItem,
            this.skinRibbonGalleryBarItem,
            this.barSubItemNavigation,
            this.employeesBarButtonItem,
            this.customersBarButtonItem,
            this.bbiNuevo,
            this.bbiCancelar,
            this.bbiGuardar,
            this.bbiImprimir,
            this.bbiCerrar,
            this.bbiRegresar,
            this.bbiCargarfacturas,
            this.bbiTodos,
            this.bbiRegistrados,
            this.bbiCancelados,
            this.bbiVerificar,
            this.bbiEnviar,
            this.bbiCargarCxC});
            this.ribbonControl.Location = new System.Drawing.Point(0, 0);
            this.ribbonControl.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.ribbonControl.MaxItemId = 7;
            this.ribbonControl.MdiMergeStyle = DevExpress.XtraBars.Ribbon.RibbonMdiMergeStyle.Always;
            this.ribbonControl.Name = "ribbonControl";
            this.ribbonControl.Pages.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPage[] {
            this.ribbonPage,
            this.ribbonPage1});
            this.ribbonControl.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonControlStyle.Office2013;
            this.ribbonControl.ShowApplicationButton = DevExpress.Utils.DefaultBoolean.False;
            this.ribbonControl.Size = new System.Drawing.Size(1915, 181);
            this.ribbonControl.StatusBar = this.ribbonStatusBar;
            this.ribbonControl.ToolbarLocation = DevExpress.XtraBars.Ribbon.RibbonQuickAccessToolbarLocation.Hidden;
            // 
            // skinRibbonGalleryBarItem
            // 
            this.skinRibbonGalleryBarItem.Id = 14;
            this.skinRibbonGalleryBarItem.Name = "skinRibbonGalleryBarItem";
            // 
            // barSubItemNavigation
            // 
            this.barSubItemNavigation.Caption = "Navigation";
            this.barSubItemNavigation.Id = 15;
            this.barSubItemNavigation.ImageOptions.ImageUri.Uri = "NavigationBar";
            this.barSubItemNavigation.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.employeesBarButtonItem),
            new DevExpress.XtraBars.LinkPersistInfo(this.customersBarButtonItem)});
            this.barSubItemNavigation.Name = "barSubItemNavigation";
            // 
            // employeesBarButtonItem
            // 
            this.employeesBarButtonItem.Id = 52;
            this.employeesBarButtonItem.Name = "employeesBarButtonItem";
            // 
            // customersBarButtonItem
            // 
            this.customersBarButtonItem.Id = 53;
            this.customersBarButtonItem.Name = "customersBarButtonItem";
            // 
            // bbiNuevo
            // 
            this.bbiNuevo.Caption = "Nuevo";
            this.bbiNuevo.Id = 46;
            this.bbiNuevo.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("bbiNuevo.ImageOptions.Image")));
            this.bbiNuevo.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("bbiNuevo.ImageOptions.LargeImage")));
            this.bbiNuevo.Name = "bbiNuevo";
            this.bbiNuevo.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.bbiNuevo_ItemClick);
            // 
            // bbiCancelar
            // 
            this.bbiCancelar.Caption = "Cancelar";
            this.bbiCancelar.Id = 47;
            this.bbiCancelar.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("bbiCancelar.ImageOptions.Image")));
            this.bbiCancelar.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("bbiCancelar.ImageOptions.LargeImage")));
            this.bbiCancelar.Name = "bbiCancelar";
            this.bbiCancelar.Visibility = DevExpress.XtraBars.BarItemVisibility.Never;
            this.bbiCancelar.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.bbiCancelar_ItemClick);
            // 
            // bbiGuardar
            // 
            this.bbiGuardar.Caption = "Guardar";
            this.bbiGuardar.Id = 48;
            this.bbiGuardar.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("bbiGuardar.ImageOptions.SvgImage")));
            this.bbiGuardar.Name = "bbiGuardar";
            this.bbiGuardar.Visibility = DevExpress.XtraBars.BarItemVisibility.Never;
            this.bbiGuardar.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.bbiGuardar_ItemClick);
            // 
            // bbiImprimir
            // 
            this.bbiImprimir.Caption = "Imprimir";
            this.bbiImprimir.Id = 49;
            this.bbiImprimir.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("bbiImprimir.ImageOptions.SvgImage")));
            this.bbiImprimir.Name = "bbiImprimir";
            this.bbiImprimir.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.bbiImprimir_ItemClick);
            // 
            // bbiCerrar
            // 
            this.bbiCerrar.Caption = "Cerrar";
            this.bbiCerrar.Id = 50;
            this.bbiCerrar.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("bbiCerrar.ImageOptions.SvgImage")));
            this.bbiCerrar.Name = "bbiCerrar";
            this.bbiCerrar.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.bbiCerrar_ItemClick);
            // 
            // bbiRegresar
            // 
            this.bbiRegresar.Caption = "Regresar";
            this.bbiRegresar.Id = 51;
            this.bbiRegresar.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("bbiRegresar.ImageOptions.Image")));
            this.bbiRegresar.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("bbiRegresar.ImageOptions.LargeImage")));
            this.bbiRegresar.Name = "bbiRegresar";
            this.bbiRegresar.Visibility = DevExpress.XtraBars.BarItemVisibility.Never;
            this.bbiRegresar.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.bbiRegresar_ItemClick);
            // 
            // bbiCargarfacturas
            // 
            this.bbiCargarfacturas.Caption = "Cargar facturas";
            this.bbiCargarfacturas.Id = 54;
            this.bbiCargarfacturas.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("bbiCargarfacturas.ImageOptions.SvgImage")));
            this.bbiCargarfacturas.Name = "bbiCargarfacturas";
            this.bbiCargarfacturas.Visibility = DevExpress.XtraBars.BarItemVisibility.Never;
            this.bbiCargarfacturas.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.bbiCargarfacturas_ItemClick);
            // 
            // bbiTodos
            // 
            this.bbiTodos.Caption = "Todos";
            this.bbiTodos.Id = 1;
            this.bbiTodos.Name = "bbiTodos";
            // 
            // bbiRegistrados
            // 
            this.bbiRegistrados.Caption = "Registrados";
            this.bbiRegistrados.Id = 2;
            this.bbiRegistrados.Name = "bbiRegistrados";
            // 
            // bbiCancelados
            // 
            this.bbiCancelados.Caption = "Cancelados";
            this.bbiCancelados.Id = 3;
            this.bbiCancelados.Name = "bbiCancelados";
            // 
            // bbiVerificar
            // 
            this.bbiVerificar.Caption = "Verificar";
            this.bbiVerificar.Id = 4;
            this.bbiVerificar.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("bbiVerificar.ImageOptions.SvgImage")));
            this.bbiVerificar.Name = "bbiVerificar";
            this.bbiVerificar.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.bbiVerificar_ItemClick);
            // 
            // bbiEnviar
            // 
            this.bbiEnviar.Caption = "Envíar por correo";
            this.bbiEnviar.Id = 5;
            this.bbiEnviar.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("bbiEnviar.ImageOptions.SvgImage")));
            this.bbiEnviar.Name = "bbiEnviar";
            this.bbiEnviar.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.bbiEnviar_ItemClick);
            // 
            // ribbonPage
            // 
            this.ribbonPage.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.ribbonPageGroupNavigation,
            this.ribbonPageGroup});
            this.ribbonPage.Name = "ribbonPage";
            this.ribbonPage.Text = "View";
            // 
            // ribbonPageGroupNavigation
            // 
            this.ribbonPageGroupNavigation.ItemLinks.Add(this.barSubItemNavigation);
            this.ribbonPageGroupNavigation.Name = "ribbonPageGroupNavigation";
            this.ribbonPageGroupNavigation.Text = "Module";
            // 
            // ribbonPageGroup
            // 
            this.ribbonPageGroup.AllowTextClipping = false;
            this.ribbonPageGroup.ItemLinks.Add(this.skinRibbonGalleryBarItem);
            this.ribbonPageGroup.Name = "ribbonPageGroup";
            this.ribbonPageGroup.ShowCaptionButton = false;
            this.ribbonPageGroup.Text = "Appearance";
            // 
            // ribbonPage1
            // 
            this.ribbonPage1.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.ribbonPageGroup1});
            this.ribbonPage1.Name = "ribbonPage1";
            this.ribbonPage1.Text = "Home";
            // 
            // ribbonPageGroup1
            // 
            this.ribbonPageGroup1.ItemLinks.Add(this.bbiNuevo);
            this.ribbonPageGroup1.ItemLinks.Add(this.bbiCancelar);
            this.ribbonPageGroup1.ItemLinks.Add(this.bbiGuardar);
            this.ribbonPageGroup1.ItemLinks.Add(this.bbiImprimir);
            this.ribbonPageGroup1.ItemLinks.Add(this.bbiCargarCxC);
            this.ribbonPageGroup1.ItemLinks.Add(this.bbiRegresar);
            this.ribbonPageGroup1.ItemLinks.Add(this.bbiVerificar);
            this.ribbonPageGroup1.ItemLinks.Add(this.bbiEnviar);
            this.ribbonPageGroup1.ItemLinks.Add(this.bbiCerrar);
            this.ribbonPageGroup1.Name = "ribbonPageGroup1";
            this.ribbonPageGroup1.Text = "Acciones";
            // 
            // ribbonStatusBar
            // 
            this.ribbonStatusBar.ItemLinks.Add(this.bbiRegistrados);
            this.ribbonStatusBar.ItemLinks.Add(this.bbiCancelados);
            this.ribbonStatusBar.ItemLinks.Add(this.bbiTodos);
            this.ribbonStatusBar.Location = new System.Drawing.Point(0, 780);
            this.ribbonStatusBar.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.ribbonStatusBar.Name = "ribbonStatusBar";
            this.ribbonStatusBar.Ribbon = this.ribbonControl;
            this.ribbonStatusBar.Size = new System.Drawing.Size(1915, 29);
            // 
            // officeNavigationBar
            // 
            this.officeNavigationBar.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.officeNavigationBar.Location = new System.Drawing.Point(0, 728);
            this.officeNavigationBar.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.officeNavigationBar.Name = "officeNavigationBar";
            this.officeNavigationBar.NavigationClient = this.navBarControl;
            this.officeNavigationBar.Size = new System.Drawing.Size(1915, 52);
            this.officeNavigationBar.TabIndex = 1;
            this.officeNavigationBar.Text = "officeNavigationBar";
            // 
            // navBarControl
            // 
            this.navBarControl.ActiveGroup = this.employeesNavBarGroup;
            this.navBarControl.Dock = System.Windows.Forms.DockStyle.Left;
            this.navBarControl.Groups.AddRange(new DevExpress.XtraNavBar.NavBarGroup[] {
            this.employeesNavBarGroup});
            this.navBarControl.Items.AddRange(new DevExpress.XtraNavBar.NavBarItem[] {
            this.navBarItemEne,
            this.navBarItemFeb,
            this.navBarItemMar,
            this.navBarItemAbr,
            this.navBarItemMay,
            this.navBarItemJun,
            this.navBarItemJul,
            this.navBarItemAgo,
            this.navBarItemsep,
            this.navBarItemOct,
            this.navBarItemNov,
            this.navBarItemDic,
            this.navBarItemTodos});
            this.navBarControl.Location = new System.Drawing.Point(0, 181);
            this.navBarControl.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.navBarControl.Name = "navBarControl";
            this.navBarControl.OptionsNavPane.ExpandedWidth = 192;
            this.navBarControl.PaintStyleKind = DevExpress.XtraNavBar.NavBarViewKind.NavigationPane;
            this.navBarControl.Size = new System.Drawing.Size(192, 547);
            this.navBarControl.TabIndex = 0;
            this.navBarControl.Text = "navBarControl";
            // 
            // employeesNavBarGroup
            // 
            this.employeesNavBarGroup.Caption = "Filtros";
            this.employeesNavBarGroup.Expanded = true;
            this.employeesNavBarGroup.ItemLinks.AddRange(new DevExpress.XtraNavBar.NavBarItemLink[] {
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItemEne),
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItemFeb),
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItemMar),
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItemAbr),
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItemMay),
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItemJun),
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItemJul),
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItemAgo),
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItemsep),
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItemOct),
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItemNov),
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItemDic),
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItemTodos)});
            this.employeesNavBarGroup.Name = "employeesNavBarGroup";
            // 
            // navBarItemEne
            // 
            this.navBarItemEne.Caption = "Enero";
            this.navBarItemEne.Name = "navBarItemEne";
            this.navBarItemEne.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.navBarItemEne_LinkClicked_1);
            // 
            // navBarItemFeb
            // 
            this.navBarItemFeb.Caption = "Febrero";
            this.navBarItemFeb.Name = "navBarItemFeb";
            this.navBarItemFeb.LinkPressed += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.navBarItemFeb_LinkPressed);
            // 
            // navBarItemMar
            // 
            this.navBarItemMar.Caption = "Marzo";
            this.navBarItemMar.Name = "navBarItemMar";
            this.navBarItemMar.LinkPressed += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.navBarItemMar_LinkPressed);
            // 
            // navBarItemAbr
            // 
            this.navBarItemAbr.Caption = "Abril";
            this.navBarItemAbr.Name = "navBarItemAbr";
            this.navBarItemAbr.LinkPressed += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.navBarItemAbr_LinkPressed);
            // 
            // navBarItemMay
            // 
            this.navBarItemMay.Caption = "Mayo";
            this.navBarItemMay.Name = "navBarItemMay";
            this.navBarItemMay.LinkPressed += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.navBarItemMay_LinkPressed);
            // 
            // navBarItemJun
            // 
            this.navBarItemJun.Caption = "Junio";
            this.navBarItemJun.Name = "navBarItemJun";
            this.navBarItemJun.LinkPressed += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.navBarItemJun_LinkPressed);
            // 
            // navBarItemJul
            // 
            this.navBarItemJul.Caption = "Julio";
            this.navBarItemJul.Name = "navBarItemJul";
            this.navBarItemJul.LinkPressed += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.navBarItemJul_LinkPressed);
            // 
            // navBarItemAgo
            // 
            this.navBarItemAgo.Caption = "Agosto";
            this.navBarItemAgo.Name = "navBarItemAgo";
            this.navBarItemAgo.LinkPressed += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.navBarItemAgo_LinkPressed);
            // 
            // navBarItemsep
            // 
            this.navBarItemsep.Caption = "Septiembre";
            this.navBarItemsep.Name = "navBarItemsep";
            this.navBarItemsep.LinkPressed += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.navBarItemsep_LinkPressed);
            // 
            // navBarItemOct
            // 
            this.navBarItemOct.Caption = "Octubre";
            this.navBarItemOct.Name = "navBarItemOct";
            this.navBarItemOct.LinkPressed += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.navBarItemOct_LinkPressed);
            // 
            // navBarItemNov
            // 
            this.navBarItemNov.Caption = "Noviembre";
            this.navBarItemNov.Name = "navBarItemNov";
            this.navBarItemNov.LinkPressed += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.navBarItemNov_LinkPressed);
            // 
            // navBarItemDic
            // 
            this.navBarItemDic.Caption = "Diciembre";
            this.navBarItemDic.Name = "navBarItemDic";
            this.navBarItemDic.LinkPressed += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.navBarItemDic_LinkPressed);
            // 
            // navBarItemTodos
            // 
            this.navBarItemTodos.Caption = "Todos";
            this.navBarItemTodos.Name = "navBarItemTodos";
            this.navBarItemTodos.LinkPressed += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.navBarItemTodos_LinkPressed);
            // 
            // navigationFrame
            // 
            this.navigationFrame.Appearance.BackColor = System.Drawing.Color.White;
            this.navigationFrame.Appearance.Options.UseBackColor = true;
            this.navigationFrame.Controls.Add(this.employeesNavigationPage);
            this.navigationFrame.Controls.Add(this.customersNavigationPage);
            this.navigationFrame.Dock = System.Windows.Forms.DockStyle.Fill;
            this.navigationFrame.Location = new System.Drawing.Point(192, 181);
            this.navigationFrame.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.navigationFrame.Name = "navigationFrame";
            this.navigationFrame.Pages.AddRange(new DevExpress.XtraBars.Navigation.NavigationPageBase[] {
            this.employeesNavigationPage,
            this.customersNavigationPage});
            this.navigationFrame.RibbonAndBarsMergeStyle = DevExpress.XtraBars.Docking2010.Views.RibbonAndBarsMergeStyle.Always;
            this.navigationFrame.SelectedPage = this.employeesNavigationPage;
            this.navigationFrame.Size = new System.Drawing.Size(1723, 547);
            this.navigationFrame.TabIndex = 0;
            this.navigationFrame.Text = "navigationFrame";
            // 
            // employeesNavigationPage
            // 
            this.employeesNavigationPage.Controls.Add(this.popUpCancelar);
            this.employeesNavigationPage.Controls.Add(this.gridControlPrincipal);
            this.employeesNavigationPage.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.employeesNavigationPage.Name = "employeesNavigationPage";
            this.employeesNavigationPage.Size = new System.Drawing.Size(1723, 547);
            // 
            // popUpCancelar
            // 
            this.popUpCancelar.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Simple;
            this.popUpCancelar.Controls.Add(this.groupControl3);
            this.popUpCancelar.Location = new System.Drawing.Point(472, 139);
            this.popUpCancelar.Name = "popUpCancelar";
            this.popUpCancelar.ShowCloseButton = true;
            this.popUpCancelar.ShowSizeGrip = true;
            this.popUpCancelar.Size = new System.Drawing.Size(529, 269);
            this.popUpCancelar.TabIndex = 2;
            this.popUpCancelar.Visible = false;
            // 
            // groupControl3
            // 
            this.groupControl3.Controls.Add(this.simpleButton2);
            this.groupControl3.Controls.Add(this.labelControl20);
            this.groupControl3.Controls.Add(this.labelControl19);
            this.groupControl3.Controls.Add(this.btnAut);
            this.groupControl3.Controls.Add(this.txtPassword);
            this.groupControl3.Controls.Add(this.txtLogin);
            this.groupControl3.Controls.Add(this.labelControl18);
            this.groupControl3.Controls.Add(this.labelControl17);
            this.groupControl3.Location = new System.Drawing.Point(30, 17);
            this.groupControl3.Name = "groupControl3";
            this.groupControl3.Size = new System.Drawing.Size(469, 233);
            this.groupControl3.TabIndex = 5;
            this.groupControl3.Text = "Cancelar el depósito";
            // 
            // simpleButton2
            // 
            this.simpleButton2.Location = new System.Drawing.Point(31, 176);
            this.simpleButton2.Name = "simpleButton2";
            this.simpleButton2.Size = new System.Drawing.Size(94, 29);
            this.simpleButton2.TabIndex = 12;
            this.simpleButton2.Text = "Cerrar";
            this.simpleButton2.Click += new System.EventHandler(this.simpleButton2_Click);
            // 
            // labelControl20
            // 
            this.labelControl20.Location = new System.Drawing.Point(31, 103);
            this.labelControl20.Name = "labelControl20";
            this.labelControl20.Size = new System.Drawing.Size(55, 16);
            this.labelControl20.TabIndex = 11;
            this.labelControl20.Text = "Password";
            // 
            // labelControl19
            // 
            this.labelControl19.Location = new System.Drawing.Point(31, 55);
            this.labelControl19.Name = "labelControl19";
            this.labelControl19.Size = new System.Drawing.Size(30, 16);
            this.labelControl19.TabIndex = 10;
            this.labelControl19.Text = "Login";
            // 
            // btnAut
            // 
            this.btnAut.Location = new System.Drawing.Point(348, 176);
            this.btnAut.Name = "btnAut";
            this.btnAut.Size = new System.Drawing.Size(94, 29);
            this.btnAut.TabIndex = 9;
            this.btnAut.Text = "Cancelar";
            this.btnAut.Click += new System.EventHandler(this.btnAut_Click);
            // 
            // txtPassword
            // 
            this.txtPassword.Location = new System.Drawing.Point(141, 97);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.Properties.PasswordChar = '*';
            this.txtPassword.Size = new System.Drawing.Size(210, 22);
            this.txtPassword.TabIndex = 8;
            // 
            // txtLogin
            // 
            this.txtLogin.Location = new System.Drawing.Point(141, 49);
            this.txtLogin.Name = "txtLogin";
            this.txtLogin.Size = new System.Drawing.Size(210, 22);
            this.txtLogin.TabIndex = 7;
            // 
            // labelControl18
            // 
            this.labelControl18.Location = new System.Drawing.Point(-117, 60);
            this.labelControl18.Name = "labelControl18";
            this.labelControl18.Size = new System.Drawing.Size(55, 16);
            this.labelControl18.TabIndex = 6;
            this.labelControl18.Text = "Password";
            // 
            // labelControl17
            // 
            this.labelControl17.Location = new System.Drawing.Point(-117, 12);
            this.labelControl17.Name = "labelControl17";
            this.labelControl17.Size = new System.Drawing.Size(30, 16);
            this.labelControl17.TabIndex = 5;
            this.labelControl17.Text = "Login";
            // 
            // gridControlPrincipal
            // 
            this.gridControlPrincipal.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gridControlPrincipal.EmbeddedNavigator.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.gridControlPrincipal.Location = new System.Drawing.Point(0, 0);
            this.gridControlPrincipal.MainView = this.gridViewPrincipal;
            this.gridControlPrincipal.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.gridControlPrincipal.MenuManager = this.ribbonControl;
            this.gridControlPrincipal.Name = "gridControlPrincipal";
            this.gridControlPrincipal.Size = new System.Drawing.Size(1723, 547);
            this.gridControlPrincipal.TabIndex = 0;
            this.gridControlPrincipal.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridViewPrincipal});
            // 
            // gridViewPrincipal
            // 
            this.gridViewPrincipal.DetailHeight = 431;
            this.gridViewPrincipal.GridControl = this.gridControlPrincipal;
            this.gridViewPrincipal.Name = "gridViewPrincipal";
            this.gridViewPrincipal.RowClick += new DevExpress.XtraGrid.Views.Grid.RowClickEventHandler(this.gridViewPrincipal_RowClick);
            this.gridViewPrincipal.RowCellStyle += new DevExpress.XtraGrid.Views.Grid.RowCellStyleEventHandler(this.gridViewPrincipal_RowCellStyle);
            // 
            // customersNavigationPage
            // 
            this.customersNavigationPage.Controls.Add(this.splitContainerControl1);
            this.customersNavigationPage.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.customersNavigationPage.Name = "customersNavigationPage";
            this.customersNavigationPage.Size = new System.Drawing.Size(1723, 547);
            // 
            // splitContainerControl1
            // 
            this.splitContainerControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainerControl1.Horizontal = false;
            this.splitContainerControl1.Location = new System.Drawing.Point(0, 0);
            this.splitContainerControl1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.splitContainerControl1.Name = "splitContainerControl1";
            this.splitContainerControl1.Panel1.Appearance.BackColor = System.Drawing.Color.Transparent;
            this.splitContainerControl1.Panel1.Appearance.Options.UseBackColor = true;
            this.splitContainerControl1.Panel1.Controls.Add(this.chkTimbrar);
            this.splitContainerControl1.Panel1.Controls.Add(this.labelControl12);
            this.splitContainerControl1.Panel1.Controls.Add(this.labelControl11);
            this.splitContainerControl1.Panel1.Controls.Add(this.txtFolio);
            this.splitContainerControl1.Panel1.Controls.Add(this.cboSerie);
            this.splitContainerControl1.Panel1.Controls.Add(this.groupControl2);
            this.splitContainerControl1.Panel1.Controls.Add(this.groupControl1);
            this.splitContainerControl1.Panel1.Text = "Panel1";
            this.splitContainerControl1.Panel2.Controls.Add(this.gridControlDetalle);
            this.splitContainerControl1.Panel2.Text = "Panel2";
            this.splitContainerControl1.Size = new System.Drawing.Size(1723, 547);
            this.splitContainerControl1.SplitterPosition = 279;
            this.splitContainerControl1.TabIndex = 0;
            // 
            // chkTimbrar
            // 
            this.chkTimbrar.Location = new System.Drawing.Point(1435, 109);
            this.chkTimbrar.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.chkTimbrar.MenuManager = this.ribbonControl;
            this.chkTimbrar.Name = "chkTimbrar";
            this.chkTimbrar.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.chkTimbrar.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.chkTimbrar.Properties.Appearance.Options.UseFont = true;
            this.chkTimbrar.Properties.Appearance.Options.UseForeColor = true;
            this.chkTimbrar.Properties.Caption = "Timbrar";
            this.chkTimbrar.Size = new System.Drawing.Size(87, 21);
            this.chkTimbrar.TabIndex = 14;
            // 
            // labelControl12
            // 
            this.labelControl12.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.labelControl12.Appearance.ForeColor = System.Drawing.Color.Black;
            this.labelControl12.Appearance.Options.UseFont = true;
            this.labelControl12.Appearance.Options.UseForeColor = true;
            this.labelControl12.Location = new System.Drawing.Point(1380, 75);
            this.labelControl12.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.labelControl12.Name = "labelControl12";
            this.labelControl12.Size = new System.Drawing.Size(32, 17);
            this.labelControl12.TabIndex = 13;
            this.labelControl12.Text = "Folio:";
            // 
            // labelControl11
            // 
            this.labelControl11.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.labelControl11.Appearance.ForeColor = System.Drawing.Color.Black;
            this.labelControl11.Appearance.Options.UseFont = true;
            this.labelControl11.Appearance.Options.UseForeColor = true;
            this.labelControl11.Location = new System.Drawing.Point(1378, 38);
            this.labelControl11.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.labelControl11.Name = "labelControl11";
            this.labelControl11.Size = new System.Drawing.Size(34, 17);
            this.labelControl11.TabIndex = 12;
            this.labelControl11.Text = "Serie:";
            // 
            // txtFolio
            // 
            this.txtFolio.Enabled = false;
            this.txtFolio.Location = new System.Drawing.Point(1435, 71);
            this.txtFolio.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtFolio.MenuManager = this.ribbonControl;
            this.txtFolio.Name = "txtFolio";
            this.txtFolio.Size = new System.Drawing.Size(86, 22);
            this.txtFolio.TabIndex = 11;
            // 
            // cboSerie
            // 
            this.cboSerie.Location = new System.Drawing.Point(1435, 34);
            this.cboSerie.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.cboSerie.MenuManager = this.ribbonControl;
            this.cboSerie.Name = "cboSerie";
            this.cboSerie.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.cboSerie.Size = new System.Drawing.Size(86, 22);
            this.cboSerie.TabIndex = 10;
            // 
            // groupControl2
            // 
            this.groupControl2.Appearance.BackColor = System.Drawing.Color.Transparent;
            this.groupControl2.Appearance.BorderColor = System.Drawing.Color.Transparent;
            this.groupControl2.Appearance.Options.UseBackColor = true;
            this.groupControl2.Appearance.Options.UseBorderColor = true;
            this.groupControl2.AppearanceCaption.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.groupControl2.AppearanceCaption.ForeColor = System.Drawing.Color.Black;
            this.groupControl2.AppearanceCaption.Options.UseFont = true;
            this.groupControl2.AppearanceCaption.Options.UseForeColor = true;
            this.groupControl2.Controls.Add(this.dateEditFecha);
            this.groupControl2.Controls.Add(this.cboC_Formapago);
            this.groupControl2.Controls.Add(this.cboBancosId);
            this.groupControl2.Controls.Add(this.labelControl10);
            this.groupControl2.Controls.Add(this.labelControl9);
            this.groupControl2.Controls.Add(this.labelControl8);
            this.groupControl2.Controls.Add(this.txtNumerooperacion);
            this.groupControl2.Controls.Add(this.txtCuentaordenante);
            this.groupControl2.Controls.Add(this.labelControl7);
            this.groupControl2.Controls.Add(this.labelControl6);
            this.groupControl2.Controls.Add(this.txtHora);
            this.groupControl2.Controls.Add(this.labelControl5);
            this.groupControl2.Controls.Add(this.labelControl4);
            this.groupControl2.Controls.Add(this.cboClientesID);
            this.groupControl2.Location = new System.Drawing.Point(564, 26);
            this.groupControl2.LookAndFeel.Style = DevExpress.LookAndFeel.LookAndFeelStyle.Flat;
            this.groupControl2.LookAndFeel.UseDefaultLookAndFeel = false;
            this.groupControl2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupControl2.Name = "groupControl2";
            this.groupControl2.Size = new System.Drawing.Size(796, 224);
            this.groupControl2.TabIndex = 2;
            this.groupControl2.Text = "Datos del cliente";
            // 
            // dateEditFecha
            // 
            this.dateEditFecha.EditValue = null;
            this.dateEditFecha.Location = new System.Drawing.Point(148, 76);
            this.dateEditFecha.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dateEditFecha.MenuManager = this.ribbonControl;
            this.dateEditFecha.Name = "dateEditFecha";
            this.dateEditFecha.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.dateEditFecha.Properties.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.dateEditFecha.Size = new System.Drawing.Size(239, 24);
            this.dateEditFecha.TabIndex = 17;
            // 
            // cboC_Formapago
            // 
            this.cboC_Formapago.Location = new System.Drawing.Point(148, 175);
            this.cboC_Formapago.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.cboC_Formapago.MenuManager = this.ribbonControl;
            this.cboC_Formapago.Name = "cboC_Formapago";
            this.cboC_Formapago.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.cboC_Formapago.Size = new System.Drawing.Size(239, 24);
            this.cboC_Formapago.TabIndex = 16;
            // 
            // cboBancosId
            // 
            this.cboBancosId.Location = new System.Drawing.Point(148, 110);
            this.cboBancosId.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.cboBancosId.MenuManager = this.ribbonControl;
            this.cboBancosId.Name = "cboBancosId";
            this.cboBancosId.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.cboBancosId.Size = new System.Drawing.Size(239, 24);
            this.cboBancosId.TabIndex = 15;
            this.cboBancosId.EditValueChanged += new System.EventHandler(this.cboBancosId_EditValueChanged);
            // 
            // labelControl10
            // 
            this.labelControl10.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.labelControl10.Appearance.ForeColor = System.Drawing.Color.Black;
            this.labelControl10.Appearance.Options.UseFont = true;
            this.labelControl10.Appearance.Options.UseForeColor = true;
            this.labelControl10.Location = new System.Drawing.Point(15, 177);
            this.labelControl10.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.labelControl10.Name = "labelControl10";
            this.labelControl10.Size = new System.Drawing.Size(98, 17);
            this.labelControl10.TabIndex = 14;
            this.labelControl10.Text = "Forma de pago:";
            // 
            // labelControl9
            // 
            this.labelControl9.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.labelControl9.Appearance.ForeColor = System.Drawing.Color.Black;
            this.labelControl9.Appearance.Options.UseFont = true;
            this.labelControl9.Appearance.Options.UseForeColor = true;
            this.labelControl9.Location = new System.Drawing.Point(15, 113);
            this.labelControl9.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.labelControl9.Name = "labelControl9";
            this.labelControl9.Size = new System.Drawing.Size(43, 17);
            this.labelControl9.TabIndex = 13;
            this.labelControl9.Text = "Banco:";
            // 
            // labelControl8
            // 
            this.labelControl8.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.labelControl8.Appearance.ForeColor = System.Drawing.Color.Black;
            this.labelControl8.Appearance.Options.UseFont = true;
            this.labelControl8.Appearance.Options.UseForeColor = true;
            this.labelControl8.Location = new System.Drawing.Point(15, 81);
            this.labelControl8.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.labelControl8.Name = "labelControl8";
            this.labelControl8.Size = new System.Drawing.Size(116, 17);
            this.labelControl8.TabIndex = 12;
            this.labelControl8.Text = "Fecha de depósito:";
            // 
            // txtNumerooperacion
            // 
            this.txtNumerooperacion.EditValue = "1";
            this.txtNumerooperacion.Location = new System.Drawing.Point(660, 110);
            this.txtNumerooperacion.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtNumerooperacion.MenuManager = this.ribbonControl;
            this.txtNumerooperacion.Name = "txtNumerooperacion";
            this.txtNumerooperacion.Size = new System.Drawing.Size(117, 24);
            this.txtNumerooperacion.TabIndex = 11;
            // 
            // txtCuentaordenante
            // 
            this.txtCuentaordenante.Location = new System.Drawing.Point(148, 143);
            this.txtCuentaordenante.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtCuentaordenante.MenuManager = this.ribbonControl;
            this.txtCuentaordenante.Name = "txtCuentaordenante";
            this.txtCuentaordenante.Size = new System.Drawing.Size(238, 24);
            this.txtCuentaordenante.TabIndex = 10;
            // 
            // labelControl7
            // 
            this.labelControl7.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.labelControl7.Appearance.ForeColor = System.Drawing.Color.Black;
            this.labelControl7.Appearance.Options.UseFont = true;
            this.labelControl7.Appearance.Options.UseForeColor = true;
            this.labelControl7.Location = new System.Drawing.Point(581, 113);
            this.labelControl7.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.labelControl7.Name = "labelControl7";
            this.labelControl7.Size = new System.Drawing.Size(67, 17);
            this.labelControl7.TabIndex = 9;
            this.labelControl7.Text = "Operación:";
            // 
            // labelControl6
            // 
            this.labelControl6.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.labelControl6.Appearance.ForeColor = System.Drawing.Color.Black;
            this.labelControl6.Appearance.Options.UseFont = true;
            this.labelControl6.Appearance.Options.UseForeColor = true;
            this.labelControl6.Location = new System.Drawing.Point(16, 146);
            this.labelControl6.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.labelControl6.Name = "labelControl6";
            this.labelControl6.Size = new System.Drawing.Size(49, 17);
            this.labelControl6.TabIndex = 8;
            this.labelControl6.Text = "Cuenta:";
            // 
            // txtHora
            // 
            this.txtHora.EditValue = "12:00";
            this.txtHora.Location = new System.Drawing.Point(660, 76);
            this.txtHora.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtHora.MenuManager = this.ribbonControl;
            this.txtHora.Name = "txtHora";
            this.txtHora.Size = new System.Drawing.Size(117, 24);
            this.txtHora.TabIndex = 7;
            this.txtHora.TabStop = false;
            // 
            // labelControl5
            // 
            this.labelControl5.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.labelControl5.Appearance.ForeColor = System.Drawing.Color.Black;
            this.labelControl5.Appearance.Options.UseFont = true;
            this.labelControl5.Appearance.Options.UseForeColor = true;
            this.labelControl5.Location = new System.Drawing.Point(583, 81);
            this.labelControl5.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.labelControl5.Name = "labelControl5";
            this.labelControl5.Size = new System.Drawing.Size(34, 17);
            this.labelControl5.TabIndex = 6;
            this.labelControl5.Text = "Hora:";
            // 
            // labelControl4
            // 
            this.labelControl4.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.labelControl4.Appearance.ForeColor = System.Drawing.Color.Black;
            this.labelControl4.Appearance.Options.UseFont = true;
            this.labelControl4.Appearance.Options.UseForeColor = true;
            this.labelControl4.Location = new System.Drawing.Point(19, 44);
            this.labelControl4.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.labelControl4.Name = "labelControl4";
            this.labelControl4.Size = new System.Drawing.Size(45, 17);
            this.labelControl4.TabIndex = 5;
            this.labelControl4.Text = "Cliente:";
            // 
            // cboClientesID
            // 
            this.cboClientesID.Location = new System.Drawing.Point(148, 41);
            this.cboClientesID.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.cboClientesID.MenuManager = this.ribbonControl;
            this.cboClientesID.Name = "cboClientesID";
            this.cboClientesID.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.cboClientesID.Size = new System.Drawing.Size(454, 24);
            this.cboClientesID.TabIndex = 0;
            this.cboClientesID.EditValueChanged += new System.EventHandler(this.cboClientesID_EditValueChanged);
            this.cboClientesID.EditValueChanging += new DevExpress.XtraEditors.Controls.ChangingEventHandler(this.cboClientesID_EditValueChanging);
            // 
            // groupControl1
            // 
            this.groupControl1.Appearance.BackColor = System.Drawing.Color.Transparent;
            this.groupControl1.Appearance.BackColor2 = System.Drawing.Color.Transparent;
            this.groupControl1.Appearance.BorderColor = System.Drawing.Color.Transparent;
            this.groupControl1.Appearance.Options.UseBackColor = true;
            this.groupControl1.Appearance.Options.UseBorderColor = true;
            this.groupControl1.AppearanceCaption.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.groupControl1.AppearanceCaption.ForeColor = System.Drawing.Color.Black;
            this.groupControl1.AppearanceCaption.Options.UseFont = true;
            this.groupControl1.AppearanceCaption.Options.UseForeColor = true;
            this.groupControl1.Controls.Add(this.btnTomaImporte);
            this.groupControl1.Controls.Add(this.txtTipodecambio);
            this.groupControl1.Controls.Add(this.labelControl3);
            this.groupControl1.Controls.Add(this.txtImporte);
            this.groupControl1.Controls.Add(this.labelControl2);
            this.groupControl1.Controls.Add(this.labelControl1);
            this.groupControl1.Controls.Add(this.cboCuentasbancariaID);
            this.groupControl1.Location = new System.Drawing.Point(21, 26);
            this.groupControl1.LookAndFeel.Style = DevExpress.LookAndFeel.LookAndFeelStyle.Flat;
            this.groupControl1.LookAndFeel.UseDefaultLookAndFeel = false;
            this.groupControl1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupControl1.Name = "groupControl1";
            this.groupControl1.Size = new System.Drawing.Size(522, 224);
            this.groupControl1.TabIndex = 0;
            this.groupControl1.Text = "Datos del beneficiario";
            // 
            // txtTipodecambio
            // 
            this.txtTipodecambio.Location = new System.Drawing.Point(128, 114);
            this.txtTipodecambio.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtTipodecambio.MenuManager = this.ribbonControl;
            this.txtTipodecambio.Name = "txtTipodecambio";
            this.txtTipodecambio.Size = new System.Drawing.Size(163, 24);
            this.txtTipodecambio.TabIndex = 11;
            // 
            // labelControl3
            // 
            this.labelControl3.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.labelControl3.Appearance.ForeColor = System.Drawing.Color.Black;
            this.labelControl3.Appearance.Options.UseFont = true;
            this.labelControl3.Appearance.Options.UseForeColor = true;
            this.labelControl3.Location = new System.Drawing.Point(19, 118);
            this.labelControl3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.labelControl3.Name = "labelControl3";
            this.labelControl3.Size = new System.Drawing.Size(98, 17);
            this.labelControl3.TabIndex = 10;
            this.labelControl3.Text = "Tipo de cambio:";
            // 
            // txtImporte
            // 
            this.txtImporte.Location = new System.Drawing.Point(128, 76);
            this.txtImporte.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtImporte.MenuManager = this.ribbonControl;
            this.txtImporte.Name = "txtImporte";
            this.txtImporte.Size = new System.Drawing.Size(163, 24);
            this.txtImporte.TabIndex = 4;
            // 
            // labelControl2
            // 
            this.labelControl2.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.labelControl2.Appearance.ForeColor = System.Drawing.Color.Black;
            this.labelControl2.Appearance.Options.UseFont = true;
            this.labelControl2.Appearance.Options.UseForeColor = true;
            this.labelControl2.Location = new System.Drawing.Point(19, 80);
            this.labelControl2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.labelControl2.Name = "labelControl2";
            this.labelControl2.Size = new System.Drawing.Size(54, 17);
            this.labelControl2.TabIndex = 2;
            this.labelControl2.Text = "Importe:";
            // 
            // labelControl1
            // 
            this.labelControl1.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.labelControl1.Appearance.ForeColor = System.Drawing.Color.Black;
            this.labelControl1.Appearance.Options.UseFont = true;
            this.labelControl1.Appearance.Options.UseForeColor = true;
            this.labelControl1.Location = new System.Drawing.Point(19, 43);
            this.labelControl1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.labelControl1.Name = "labelControl1";
            this.labelControl1.Size = new System.Drawing.Size(49, 17);
            this.labelControl1.TabIndex = 1;
            this.labelControl1.Text = "Cuenta:";
            // 
            // cboCuentasbancariaID
            // 
            this.cboCuentasbancariaID.Location = new System.Drawing.Point(128, 41);
            this.cboCuentasbancariaID.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.cboCuentasbancariaID.MenuManager = this.ribbonControl;
            this.cboCuentasbancariaID.Name = "cboCuentasbancariaID";
            this.cboCuentasbancariaID.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.cboCuentasbancariaID.Size = new System.Drawing.Size(229, 24);
            this.cboCuentasbancariaID.TabIndex = 0;
            this.cboCuentasbancariaID.EditValueChanged += new System.EventHandler(this.cboCuentasbancariaID_EditValueChanged);
            // 
            // gridControlDetalle
            // 
            this.gridControlDetalle.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gridControlDetalle.EmbeddedNavigator.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.gridControlDetalle.Location = new System.Drawing.Point(0, 0);
            this.gridControlDetalle.MainView = this.gridViewDetalle;
            this.gridControlDetalle.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.gridControlDetalle.MenuManager = this.ribbonControl;
            this.gridControlDetalle.Name = "gridControlDetalle";
            this.gridControlDetalle.Size = new System.Drawing.Size(1723, 253);
            this.gridControlDetalle.TabIndex = 0;
            this.gridControlDetalle.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridViewDetalle});
            // 
            // gridViewDetalle
            // 
            this.gridViewDetalle.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumnSeriecfdi,
            this.gridColumnFoliocfdi,
            this.gridColumnFechafac,
            this.gridColumnFechavence,
            this.gridColumnImporte,
            this.gridColumnSupago,
            this.gridColumnDiasvence,
            this.gridColumnMoneda,
            this.gridColumnCxCID,
            this.gridColumnTipoMov,
            this.gridColumnMP});
            this.gridViewDetalle.DetailHeight = 431;
            this.gridViewDetalle.GridControl = this.gridControlDetalle;
            this.gridViewDetalle.Name = "gridViewDetalle";
            this.gridViewDetalle.OptionsView.ShowGroupPanel = false;
            this.gridViewDetalle.SelectionChanged += new DevExpress.Data.SelectionChangedEventHandler(this.gridViewDetalle_SelectionChanged);
            // 
            // gridColumnSeriecfdi
            // 
            this.gridColumnSeriecfdi.Caption = "Serie";
            this.gridColumnSeriecfdi.FieldName = "SerieFactura";
            this.gridColumnSeriecfdi.MinWidth = 23;
            this.gridColumnSeriecfdi.Name = "gridColumnSeriecfdi";
            this.gridColumnSeriecfdi.Visible = true;
            this.gridColumnSeriecfdi.VisibleIndex = 0;
            this.gridColumnSeriecfdi.Width = 87;
            // 
            // gridColumnFoliocfdi
            // 
            this.gridColumnFoliocfdi.Caption = "Folio";
            this.gridColumnFoliocfdi.FieldName = "Factura";
            this.gridColumnFoliocfdi.MinWidth = 23;
            this.gridColumnFoliocfdi.Name = "gridColumnFoliocfdi";
            this.gridColumnFoliocfdi.Visible = true;
            this.gridColumnFoliocfdi.VisibleIndex = 1;
            this.gridColumnFoliocfdi.Width = 87;
            // 
            // gridColumnFechafac
            // 
            this.gridColumnFechafac.Caption = "Fecha";
            this.gridColumnFechafac.FieldName = "Fecha";
            this.gridColumnFechafac.MinWidth = 23;
            this.gridColumnFechafac.Name = "gridColumnFechafac";
            this.gridColumnFechafac.Visible = true;
            this.gridColumnFechafac.VisibleIndex = 2;
            this.gridColumnFechafac.Width = 87;
            // 
            // gridColumnFechavence
            // 
            this.gridColumnFechavence.Caption = "Vence";
            this.gridColumnFechavence.FieldName = "FechaVence";
            this.gridColumnFechavence.MinWidth = 23;
            this.gridColumnFechavence.Name = "gridColumnFechavence";
            this.gridColumnFechavence.Visible = true;
            this.gridColumnFechavence.VisibleIndex = 3;
            this.gridColumnFechavence.Width = 87;
            // 
            // gridColumnImporte
            // 
            this.gridColumnImporte.Caption = "Importe";
            this.gridColumnImporte.DisplayFormat.FormatString = "{0:c2}";
            this.gridColumnImporte.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumnImporte.FieldName = "Importe";
            this.gridColumnImporte.MinWidth = 23;
            this.gridColumnImporte.Name = "gridColumnImporte";
            this.gridColumnImporte.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Sum, "Importe", "{0:c2}")});
            this.gridColumnImporte.Visible = true;
            this.gridColumnImporte.VisibleIndex = 4;
            this.gridColumnImporte.Width = 87;
            // 
            // gridColumnSupago
            // 
            this.gridColumnSupago.Caption = "Su pago";
            this.gridColumnSupago.DisplayFormat.FormatString = "{0:c2}";
            this.gridColumnSupago.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumnSupago.FieldName = "APagar";
            this.gridColumnSupago.MinWidth = 23;
            this.gridColumnSupago.Name = "gridColumnSupago";
            this.gridColumnSupago.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Sum, "APagar", "{0:c2}")});
            this.gridColumnSupago.Visible = true;
            this.gridColumnSupago.VisibleIndex = 5;
            this.gridColumnSupago.Width = 87;
            // 
            // gridColumnDiasvence
            // 
            this.gridColumnDiasvence.Caption = "Días";
            this.gridColumnDiasvence.FieldName = "DiasVenc";
            this.gridColumnDiasvence.MinWidth = 23;
            this.gridColumnDiasvence.Name = "gridColumnDiasvence";
            this.gridColumnDiasvence.Visible = true;
            this.gridColumnDiasvence.VisibleIndex = 6;
            this.gridColumnDiasvence.Width = 87;
            // 
            // gridColumnMoneda
            // 
            this.gridColumnMoneda.Caption = "Moneda";
            this.gridColumnMoneda.FieldName = "Moneda";
            this.gridColumnMoneda.MinWidth = 23;
            this.gridColumnMoneda.Name = "gridColumnMoneda";
            this.gridColumnMoneda.Visible = true;
            this.gridColumnMoneda.VisibleIndex = 7;
            this.gridColumnMoneda.Width = 87;
            // 
            // gridColumnCxCID
            // 
            this.gridColumnCxCID.Caption = "CxCID";
            this.gridColumnCxCID.FieldName = "CxCID";
            this.gridColumnCxCID.MinWidth = 25;
            this.gridColumnCxCID.Name = "gridColumnCxCID";
            this.gridColumnCxCID.Width = 94;
            // 
            // gridColumnTipoMov
            // 
            this.gridColumnTipoMov.Caption = "TipoMov";
            this.gridColumnTipoMov.FieldName = "TipoMov";
            this.gridColumnTipoMov.MinWidth = 25;
            this.gridColumnTipoMov.Name = "gridColumnTipoMov";
            this.gridColumnTipoMov.Width = 94;
            // 
            // gridColumnMP
            // 
            this.gridColumnMP.Caption = "MP";
            this.gridColumnMP.FieldName = "MP";
            this.gridColumnMP.MinWidth = 25;
            this.gridColumnMP.Name = "gridColumnMP";
            this.gridColumnMP.Visible = true;
            this.gridColumnMP.VisibleIndex = 8;
            this.gridColumnMP.Width = 94;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // bbiCargarCxC
            // 
            this.bbiCargarCxC.Caption = "Cargar CxC";
            this.bbiCargarCxC.Id = 6;
            this.bbiCargarCxC.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("bbiCargarCxC.ImageOptions.SvgImage")));
            this.bbiCargarCxC.Name = "bbiCargarCxC";
            this.bbiCargarCxC.Visibility = DevExpress.XtraBars.BarItemVisibility.Never;
            this.bbiCargarCxC.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.bbiCargarCxC_ItemClick);
            // 
            // btnTomaImporte
            // 
            this.btnTomaImporte.ImageOptions.Location = DevExpress.XtraEditors.ImageLocation.MiddleCenter;
            this.btnTomaImporte.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("btnTomaImporte.ImageOptions.SvgImage")));
            this.btnTomaImporte.Location = new System.Drawing.Point(297, 79);
            this.btnTomaImporte.Name = "btnTomaImporte";
            this.btnTomaImporte.Size = new System.Drawing.Size(35, 22);
            this.btnTomaImporte.TabIndex = 30;
            this.btnTomaImporte.TabStop = false;
            this.btnTomaImporte.Text = "simpleButton1";
            this.btnTomaImporte.Click += new System.EventHandler(this.btnTomaImporte_Click);
            // 
            // Depositos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1915, 809);
            this.Controls.Add(this.navigationFrame);
            this.Controls.Add(this.navBarControl);
            this.Controls.Add(this.officeNavigationBar);
            this.Controls.Add(this.ribbonStatusBar);
            this.Controls.Add(this.ribbonControl);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "Depositos";
            this.Ribbon = this.ribbonControl;
            this.StatusBar = this.ribbonStatusBar;
            this.Text = "Depósitos";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            ((System.ComponentModel.ISupportInitialize)(this.tabbedView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ribbonControl)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.officeNavigationBar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.navBarControl)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.navigationFrame)).EndInit();
            this.navigationFrame.ResumeLayout(false);
            this.employeesNavigationPage.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.popUpCancelar)).EndInit();
            this.popUpCancelar.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.groupControl3)).EndInit();
            this.groupControl3.ResumeLayout(false);
            this.groupControl3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtPassword.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtLogin.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridControlPrincipal)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewPrincipal)).EndInit();
            this.customersNavigationPage.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl1)).EndInit();
            this.splitContainerControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.chkTimbrar.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtFolio.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboSerie.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl2)).EndInit();
            this.groupControl2.ResumeLayout(false);
            this.groupControl2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dateEditFecha.Properties.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateEditFecha.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboC_Formapago.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboBancosId.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtNumerooperacion.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCuentaordenante.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtHora.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboClientesID.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl1)).EndInit();
            this.groupControl1.ResumeLayout(false);
            this.groupControl1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtTipodecambio.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtImporte.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboCuentasbancariaID.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridControlDetalle)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewDetalle)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private DevExpress.XtraBars.Docking2010.Views.Tabbed.TabbedView tabbedView;
        private DevExpress.XtraBars.Ribbon.RibbonControl ribbonControl;
        private DevExpress.XtraBars.Ribbon.RibbonPage ribbonPage;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup;
        private DevExpress.XtraBars.Ribbon.RibbonStatusBar ribbonStatusBar;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroupNavigation;
        private DevExpress.XtraBars.BarSubItem barSubItemNavigation;
        private DevExpress.XtraBars.SkinRibbonGalleryBarItem skinRibbonGalleryBarItem;
        private DevExpress.XtraBars.Navigation.OfficeNavigationBar officeNavigationBar;
        private DevExpress.XtraBars.Navigation.NavigationFrame navigationFrame;
        private DevExpress.XtraNavBar.NavBarControl navBarControl;
        private DevExpress.XtraNavBar.NavBarGroup employeesNavBarGroup;
        private DevExpress.XtraBars.Navigation.NavigationPage employeesNavigationPage;
        private DevExpress.XtraBars.Navigation.NavigationPage customersNavigationPage;
        private DevExpress.XtraBars.BarButtonItem employeesBarButtonItem;
        private DevExpress.XtraBars.BarButtonItem customersBarButtonItem;
        private DevExpress.XtraGrid.GridControl gridControlPrincipal;
        private DevExpress.XtraGrid.Views.Grid.GridView gridViewPrincipal;
        private DevExpress.XtraEditors.SplitContainerControl splitContainerControl1;
        private DevExpress.XtraEditors.GroupControl groupControl1;
        private DevExpress.XtraEditors.LookUpEdit cboCuentasbancariaID;
        private DevExpress.XtraGrid.GridControl gridControlDetalle;
        private DevExpress.XtraGrid.Views.Grid.GridView gridViewDetalle;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private DevExpress.XtraEditors.LabelControl labelControl1;
        private DevExpress.XtraEditors.LabelControl labelControl2;
        private DevExpress.XtraEditors.TextEdit txtImporte;
        private DevExpress.XtraBars.BarButtonItem bbiNuevo;
        private DevExpress.XtraBars.BarButtonItem bbiCancelar;
        private DevExpress.XtraBars.Ribbon.RibbonPage ribbonPage1;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup1;
        private DevExpress.XtraBars.BarButtonItem bbiGuardar;
        private DevExpress.XtraBars.BarButtonItem bbiImprimir;
        private DevExpress.XtraBars.BarButtonItem bbiCerrar;
        private DevExpress.XtraBars.BarButtonItem bbiRegresar;
        private DevExpress.XtraEditors.TextEdit txtTipodecambio;
        private DevExpress.XtraEditors.LabelControl labelControl3;
        private DevExpress.XtraEditors.GroupControl groupControl2;
        private DevExpress.XtraEditors.DateEdit dateEditFecha;
        private DevExpress.XtraEditors.LookUpEdit cboC_Formapago;
        private DevExpress.XtraEditors.LookUpEdit cboBancosId;
        private DevExpress.XtraEditors.LabelControl labelControl10;
        private DevExpress.XtraEditors.LabelControl labelControl9;
        private DevExpress.XtraEditors.LabelControl labelControl8;
        private DevExpress.XtraEditors.TextEdit txtNumerooperacion;
        private DevExpress.XtraEditors.TextEdit txtCuentaordenante;
        private DevExpress.XtraEditors.LabelControl labelControl7;
        private DevExpress.XtraEditors.LabelControl labelControl6;
        private DevExpress.XtraEditors.TextEdit txtHora;
        private DevExpress.XtraEditors.LabelControl labelControl5;
        private DevExpress.XtraEditors.LabelControl labelControl4;
        private DevExpress.XtraEditors.LookUpEdit cboClientesID;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumnSeriecfdi;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumnFoliocfdi;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumnFechafac;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumnFechavence;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumnImporte;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumnSupago;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumnDiasvence;
        private DevExpress.XtraBars.BarButtonItem bbiCargarfacturas;
        private DevExpress.XtraNavBar.NavBarItem navBarItemEne;
        private DevExpress.XtraNavBar.NavBarItem navBarItemFeb;
        private DevExpress.XtraNavBar.NavBarItem navBarItemMar;
        private DevExpress.XtraNavBar.NavBarItem navBarItemAbr;
        private DevExpress.XtraNavBar.NavBarItem navBarItemMay;
        private DevExpress.XtraNavBar.NavBarItem navBarItemJun;
        private DevExpress.XtraNavBar.NavBarItem navBarItemJul;
        private DevExpress.XtraNavBar.NavBarItem navBarItemAgo;
        private DevExpress.XtraNavBar.NavBarItem navBarItemsep;
        private DevExpress.XtraNavBar.NavBarItem navBarItemOct;
        private DevExpress.XtraNavBar.NavBarItem navBarItemNov;
        private DevExpress.XtraNavBar.NavBarItem navBarItemDic;
        private DevExpress.XtraNavBar.NavBarItem navBarItemTodos;
        private DevExpress.XtraBars.BarButtonItem bbiTodos;
        private DevExpress.XtraBars.BarButtonItem bbiRegistrados;
        private DevExpress.XtraBars.BarButtonItem bbiCancelados;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumnMoneda;
        private DevExpress.XtraBars.PopupControlContainer popUpCancelar;
        private DevExpress.XtraEditors.GroupControl groupControl3;
        private DevExpress.XtraEditors.SimpleButton simpleButton2;
        private DevExpress.XtraEditors.LabelControl labelControl20;
        private DevExpress.XtraEditors.LabelControl labelControl19;
        private DevExpress.XtraEditors.SimpleButton btnAut;
        private DevExpress.XtraEditors.TextEdit txtPassword;
        private DevExpress.XtraEditors.TextEdit txtLogin;
        private DevExpress.XtraEditors.LabelControl labelControl18;
        private DevExpress.XtraEditors.LabelControl labelControl17;
        private DevExpress.XtraEditors.CheckEdit chkTimbrar;
        private DevExpress.XtraEditors.LabelControl labelControl12;
        private DevExpress.XtraEditors.LabelControl labelControl11;
        private DevExpress.XtraEditors.TextEdit txtFolio;
        private DevExpress.XtraEditors.LookUpEdit cboSerie;
        private DevExpress.XtraBars.BarButtonItem bbiVerificar;
        private DevExpress.XtraBars.BarButtonItem bbiEnviar;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumnCxCID;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumnTipoMov;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumnMP;
        private DevExpress.XtraBars.BarButtonItem bbiCargarCxC;
        private DevExpress.XtraEditors.SimpleButton btnTomaImporte;
    }
}